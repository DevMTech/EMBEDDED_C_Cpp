Eudyptula Challenge Task List
=============================
This is a list of the tasks in the [eudyptula challenge](http://eudyptula-challenge.org/).

The purpose of this is to be able to view tasks before you get to them.

### Contributing
Fork the repo, and create a pull request for any tasks that have not been added yet.